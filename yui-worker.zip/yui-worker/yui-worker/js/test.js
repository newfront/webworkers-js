var Insurance = {
	name: "geico"	
};

(function () {
	alert("loaded via web worker");
}());